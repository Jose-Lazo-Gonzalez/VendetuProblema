import { ChangeDetectionStrategy, Component, input } from "@angular/core";

export type ButtonVariant = "primary" | "secondary" | "disabled";

@Component({
  selector: "app-button",
  templateUrl: "./button.component.html",
  styleUrl: "./button.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ButtonComponent {
  readonly label = input.required<string>();
  readonly variant = input<ButtonVariant>("primary");
  readonly fullWidth = input(false);
}
