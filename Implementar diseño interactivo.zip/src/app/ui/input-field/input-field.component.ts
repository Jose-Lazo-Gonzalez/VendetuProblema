import { ChangeDetectionStrategy, Component, input } from "@angular/core";

export type FieldType = "text" | "password" | "select";

@Component({
  selector: "app-input-field",
  templateUrl: "./input-field.component.html",
  styleUrl: "./input-field.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class InputFieldComponent {
  readonly label = input.required<string>();
  readonly value = input.required<string>();
  readonly type = input<FieldType>("text");
  readonly error = input("");
}
