import { ChangeDetectionStrategy, Component, input } from "@angular/core";

import { ButtonComponent } from "../button/button.component";

@Component({
  selector: "app-problem-card",
  imports: [ButtonComponent],
  templateUrl: "./problem-card.component.html",
  styleUrl: "./problem-card.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ProblemCardComponent {
  readonly title = input("Web para cafetería de especialidad");
  readonly category = input("Diseño y desarrollo web");
  readonly budget = input("1.200–1.800 €");
  readonly location = input("Madrid · Remoto");
  readonly date = input("Publicado hoy");
}
