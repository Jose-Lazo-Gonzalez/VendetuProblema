import { ChangeDetectionStrategy, Component } from "@angular/core";

import { ComponentsCatalogComponent } from "./components/components-catalog/components-catalog.component";

@Component({
  selector: "app-root",
  imports: [ComponentsCatalogComponent],
  templateUrl: "./app.component.html",
  styleUrl: "./app.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {}
