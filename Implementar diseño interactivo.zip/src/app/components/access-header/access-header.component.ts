import { ChangeDetectionStrategy, Component } from "@angular/core";

import { BrandComponent } from "../brand/brand.component";

@Component({
  selector: "app-access-header",
  imports: [BrandComponent],
  templateUrl: "./access-header.component.html",
  styleUrl: "./access-header.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AccessHeaderComponent {}
