import { ChangeDetectionStrategy, Component } from "@angular/core";

@Component({
  selector: "app-role-selector",
  templateUrl: "./role-selector.component.html",
  styleUrl: "./role-selector.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RoleSelectorComponent {}
