import { ChangeDetectionStrategy, Component } from "@angular/core";

import { BrandComponent } from "../brand/brand.component";
import { ButtonComponent } from "../../ui/button/button.component";
import { InputFieldComponent } from "../../ui/input-field/input-field.component";
import { ProblemCardComponent } from "../../ui/problem-card/problem-card.component";

@Component({
  selector: "app-components-catalog",
  imports: [BrandComponent, ButtonComponent, InputFieldComponent, ProblemCardComponent],
  templateUrl: "./components-catalog.component.html",
  styleUrl: "./components-catalog.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ComponentsCatalogComponent {}
