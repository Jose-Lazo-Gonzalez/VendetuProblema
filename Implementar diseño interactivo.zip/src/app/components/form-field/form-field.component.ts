import { ChangeDetectionStrategy, Component, input } from "@angular/core";

@Component({
  selector: "app-form-field",
  templateUrl: "./form-field.component.html",
  styleUrl: "./form-field.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FormFieldComponent {
  readonly label = input.required<string>();
  readonly value = input.required<string>();
  readonly password = input(false);
}
