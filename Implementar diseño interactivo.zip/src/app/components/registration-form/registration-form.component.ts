import { ChangeDetectionStrategy, Component } from "@angular/core";

import { BrandAccentComponent } from "../brand-accent/brand-accent.component";
import { FormFieldComponent } from "../form-field/form-field.component";
import { RoleSelectorComponent } from "../role-selector/role-selector.component";
import { TermsNoticeComponent } from "../terms-notice/terms-notice.component";

@Component({
  selector: "app-registration-form",
  imports: [BrandAccentComponent, FormFieldComponent, RoleSelectorComponent, TermsNoticeComponent],
  templateUrl: "./registration-form.component.html",
  styleUrl: "./registration-form.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class RegistrationFormComponent {}
