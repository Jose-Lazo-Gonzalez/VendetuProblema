import { ChangeDetectionStrategy, Component } from "@angular/core";

@Component({
  selector: "app-terms-notice",
  templateUrl: "./terms-notice.component.html",
  styleUrl: "./terms-notice.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class TermsNoticeComponent {}
