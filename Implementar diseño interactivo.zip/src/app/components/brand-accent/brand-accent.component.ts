import { ChangeDetectionStrategy, Component } from "@angular/core";

@Component({
  selector: "app-brand-accent",
  templateUrl: "./brand-accent.component.html",
  styleUrl: "./brand-accent.component.css",
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BrandAccentComponent {}
